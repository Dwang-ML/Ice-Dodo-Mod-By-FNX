

const config = {
	chrx_id: "jhidcpailhmpjpbdbhceiaeeggkalgmd",
	dev_chrx_id: "hncbfhmjblcbjdbmddgdblbepeafmcji",
	sync_id: "@_",
}