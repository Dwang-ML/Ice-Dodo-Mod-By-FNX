

var cup_info = {
	beginner: {
		name: "Ice Dodo",
		song: "colbreakz- 10000.mp3"
	},
	carrot: {
		name: "Carrot cup",
		song: "colbreakz- 10000.mp3"
	},
	rocky: {
		name: "Rocky cup",
		song: "colbreakz- 10000.mp3"
	},
	dodo: {
		name: "Dodo cup",
		song: "colbreakz- 10000.mp3"
	},
	skilled: {
		name: "Skilled cup",
		song: "colbreakz- 10000.mp3"
	},
	furby: {
		name: "Furby cup",
		song: "colbreakz- 10000.mp3"
	},
	doom: {
		name: "Doom cup",
		song: "colbreakz- 10000.mp3"
	},
	kazil: {
		name: "Kazil cup",
		song: "colbreakz- 10000.mp3"
	},
	ye: {
		name: "Ye cup",
		song: "colbreakz- 10000.mp3"
	},
	tim: {
		name: "Tim cup",
		song: "colbreakz- 10000.mp3"
	},
	ghoul: {
		name: "Ghoul cup",
		song: "colbreakz- 10000.mp3"
	},
	rytai: {
		name: "Rytai cup",
		song: "colbreakz- 10000.mp3"
	},
	jay: {
		name: "Jay cup",
		song: "colbreakz- 10000.mp3"
	},
	crazy: {
		name: "Crazy cup",
		song: "colbreakz- 10000.mp3"
	},
	june: {
		name: "June cup",
		song: "colbreakz- 10000.mp3"
	},
	sleepy: {
		name: "Sleepy cup",
		song: "colbreakz- 10000.mp3"
	},
	mango: {
		name: "Mango cup",
		song: "colbreakz- 10000.mp3"
	},
	squirrel: {
		name: "Squirrel cup",
		song: "colbreakz- 10000.mp3"
	},
	collab: {
		name: "Collab cup",
		song: "colbreakz- 10000.mp3"
	},
	og: {
		name: "O.G. cup",
		song: "colbreakz- 10000.mp3"
	},
	vault: {
		name: "Vault cup",
		song: "colbreakz- 10000.mp3"
	},
	finder: {
		name: "Finder",
		song: "colbreakz- 10000.mp3"
	
	
	},

	rejected: {
		name: "Rejected",
		song: "colbreakz- 10000.mp3"
	},
	pilot: {
		name: "Pilot Cup",
		song: "colbreakz- 10000.mp3"
		
	}
	
	
}